const config = {
    development: {
      baseUrl: 'http://localhost:5000',
    },
    production: {
      baseUrl: 'https://nodejs.fairy-tale.bg',
    },
  };
  
  module.exports = config;
  